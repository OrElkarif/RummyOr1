package com.example.orproject;

public class CustomDialog {
}
